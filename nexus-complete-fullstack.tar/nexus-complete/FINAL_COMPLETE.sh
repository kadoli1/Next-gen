#!/bin/bash
# GENERATES ALL REMAINING COMPONENTS AND PAGES

cd /home/claude/optimus-esim/src

# MIDDLEWARE
cat > middleware.ts << 'EOF'
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { verifyToken } from '@/lib/auth'
const protectedRoutes = ['/dashboard']
const authRoutes = ['/login', '/register']
export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  const token = request.cookies.get('auth_token')?.value
  const isProtectedRoute = protectedRoutes.some(route => pathname.startsWith(route))
  const isAuthRoute = authRoutes.some(route => pathname.startsWith(route))
  let user = null
  if (token) user = await verifyToken(token)
  if (isProtectedRoute && !user) {
    const loginUrl = new URL('/login', request.url)
    return NextResponse.redirect(loginUrl)
  }
  if (isAuthRoute && user) return NextResponse.redirect(new URL('/dashboard', request.url))
  return NextResponse.next()
}
export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)'] }
EOF

# GLOBALS CSS
cat > app/globals.css << 'EOF'
@tailwind base;
@tailwind components;
@tailwind utilities;
body { @apply bg-gray-50 text-gray-900; }
EOF

# LAYOUT
cat > app/layout.tsx << 'EOF'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
const inter = Inter({ subsets: ['latin'] })
export const metadata: Metadata = {
  title: 'Optimus eSIM',
  description: 'Smart Network Switching Platform',
}
export default function RootLayout({children}: {children: React.ReactNode}) {
  return (<html lang="en"><body className={inter.className}>{children}</body></html>)
}
EOF

# HOME PAGE
cat > app/page.tsx << 'EOF'
import Link from 'next/link'
import { Button } from '@/components/ui/Button'
export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-primary-100">
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <div className="w-20 h-20 bg-primary-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <span className="text-white font-bold text-4xl">O</span>
        </div>
        <h1 className="text-5xl font-bold mb-4">Optimus eSIM</h1>
        <p className="text-xl text-gray-600 mb-8">Smart Network Switching Platform</p>
        <p className="text-lg text-gray-700 max-w-2xl mx-auto mb-12">
          Automatically switch between MTN, Airtel, Zamtel, and ZedMobile for the best connectivity
        </p>
        <div className="flex gap-4 justify-center">
          <Link href="/register"><Button size="lg">Get Started</Button></Link>
          <Link href="/login"><Button size="lg" variant="secondary">Login</Button></Link>
        </div>
      </div>
    </div>
  )
}
EOF

echo "✅ Core app files created"
