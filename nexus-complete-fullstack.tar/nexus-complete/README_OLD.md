# Optimus eSIM - Complete Network Intelligence Platform

## 🚀 Overview
Production-ready eSIM platform that automatically switches between MTN, Airtel, Zamtel, and ZedMobile networks in Zambia to deliver the highest quality internet connectivity.

## ✨ Features Included
✅ Real-time network switching simulation
✅ Usage analytics dashboard  
✅ Network performance history graphs
✅ Mobile-ready responsive design
✅ AI-powered network scoring engine
✅ User authentication & session management
✅ Data balance tracking
✅ Network preference customization
✅ Performance metrics visualization

## 🛠️ Tech Stack
- Next.js 14 (App Router)
- React 18
- TypeScript
- TailwindCSS
- SQLite (better-sqlite3)
- Recharts (analytics)
- bcryptjs (passwords)
- JWT (sessions)

## 📦 Installation

### On Replit:
1. Create new Node.js Repl
2. Upload all files
3. Run: `npm install`
4. Create `.env.local`: `cp .env.example .env.local`
5. Set JWT_SECRET in `.env.local`: Use any random 32+ char string
6. Run: `npm run db:init`
7. Run: `npm run dev`
8. Access at https://your-repl-url.repl.co

### Locally:
```bash
git clone <your-repo>
cd optimus-esim
npm install
cp .env.example .env.local
# Edit .env.local and set JWT_SECRET
npm run db:init
npm run dev
```

## 🔐 Environment Variables
```bash
JWT_SECRET=your-super-secret-key-minimum-32-characters
DATABASE_PATH=./optimus.db
NEXT_PUBLIC_APP_URL=http://localhost:3000
NODE_ENV=development
NETWORK_REFRESH_INTERVAL=5000
AUTO_SWITCH_ENABLED=true
```

## 📱 Usage
1. Register at `/register`
2. Login at `/login`
3. Access dashboard at `/dashboard`
4. View analytics at `/dashboard/analytics`
5. Check history at `/dashboard/history`

## 🎯 Network Scoring Algorithm
The AI engine scores networks based on:
- **Latency** (20-200ms range): Lower = Better
- **Cost** ($0.01-$0.10/MB): Lower = Better
- **Signal Strength** (0-100%): Higher = Better
- **Availability** (0-100% uptime): Higher = Better

Users customize weights for each factor!

## 🔄 Auto-Switching
eSIM automatically switches to the best network when:
- Score improvement > 10 points
- Current network drops below threshold
- User enables auto-switch in preferences

## 📊 Analytics Features
- Real-time network performance charts
- Usage history over time
- Cost analysis per network
- Switch frequency tracking
- Performance trends

## 🏗️ Project Structure
```
optimus-esim/
├── src/
│   ├── app/              # Next.js pages
│   ├── lib/              # Business logic
│   │   ├── db/           # Database
│   │   ├── auth/         # Authentication
│   │   ├── scoring/      # AI Engine
│   │   ├── repositories/ # Data access
│   │   └── actions/      # Server actions
│   └── components/       # React components
├── scripts/              # Build scripts
└── public/               # Static assets
```

## 🚀 Deployment

### Replit (Recommended for Free):
1. Click "Deploy"
2. Choose "Autoscale"
3. Set environment variables
4. Deploy!

### Vercel:
```bash
vercel deploy
```

### Docker:
```bash
docker build -t optimus-esim .
docker run -p 3000:3000 optimus-esim
```

## 🔧 Development

### Add New Network:
1. Add to `SEED_NETWORKS` in DB script
2. Add color to `tailwind.config.js`
3. Run `npm run db:init`

### Customize Scoring:
Edit `src/lib/scoring/engine.ts`

### Add Analytics:
Add charts in `src/components/charts/`

## 📈 Future Enhancements
- [ ] Real cellular API integration
- [ ] Machine learning predictions
- [ ] Push notifications
- [ ] PWA for mobile install
- [ ] Multi-country support
- [ ] Family plans

## 🐛 Troubleshooting

### Database errors:
```bash
rm optimus.db
npm run db:init
```

### Build errors:
```bash
rm -rf node_modules .next
npm install
npm run build
```

### Auth not working:
Check JWT_SECRET is set in `.env.local`

## 📄 License
MIT

## 👥 Support
Create an issue on GitHub

## 🎓 Learn More
- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS](https://tailwindcss.com)
- [Better SQLite3](https://github.com/WiseLibs/better-sqlite3)

---

**Built with ❤️ for Zambian Mobile Networks**
