import { getCurrentUser } from '@/lib/auth'
import { logoutAction } from '@/lib/actions/auth'
import { Button } from '../ui/Button'
export async function Header() {
  const user = await getCurrentUser()
  return (
    <header className="bg-white border-b">
      <div className="max-w-7xl mx-auto px-4 h-16 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold">O</span>
          </div>
          <h1 className="text-xl font-bold">Optimus</h1>
        </div>
        {user && (
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">{user.email}</span>
            <form action={logoutAction}>
              <Button type="submit" variant="secondary" size="sm">Logout</Button>
            </form>
          </div>
        )}
      </header>
    </div>
  )
}