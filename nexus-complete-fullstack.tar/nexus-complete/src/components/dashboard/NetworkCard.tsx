import { NetworkScore } from '@/lib/scoring/engine'
import { Card, CardHeader, CardBody } from '../ui/Card'
interface Props { network: NetworkScore; isBest: boolean }
export function NetworkCard({ network, isBest }: Props) {
  return (
    <Card className={isBest ? 'ring-2 ring-primary-500' : ''}>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-4 h-4 rounded-full" style={{ backgroundColor: network.color }} />
            <h3 className="text-lg font-semibold">{network.displayName}</h3>
          </div>
          {isBest && <span className="px-3 py-1 bg-primary-100 text-primary-700 text-sm font-medium rounded-full">Active</span>}
        </div>
      </CardHeader>
      <CardBody>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-2xl font-bold text-primary-600">{network.totalScore.toFixed(1)}</span>
            <span className="text-sm text-gray-500">Score</span>
          </div>
          <div className="space-y-2 pt-3 border-t">
            <ScoreBar label="Latency" score={network.breakdown.latencyScore} />
            <ScoreBar label="Cost" score={network.breakdown.costScore} />
            <ScoreBar label="Signal" score={network.breakdown.signalScore} />
            <ScoreBar label="Uptime" score={network.breakdown.availabilityScore} />
          </div>
          <div className="pt-3 border-t space-y-1 text-sm text-gray-600">
            <div className="flex justify-between"><span>Latency:</span><span className="font-medium">{network.metrics.latencyMs}ms</span></div>
            <div className="flex justify-between"><span>Cost:</span><span className="font-medium">${network.metrics.costPerMb.toFixed(3)}/MB</span></div>
            <div className="flex justify-between"><span>Signal:</span><span className="font-medium">{network.metrics.signalStrength}%</span></div>
          </div>
        </div>
      </CardBody>
    </Card>
  )
}
function ScoreBar({ label, score }: { label: string; score: number }) {
  return (
    <div>
      <div className="flex justify-between text-xs text-gray-600 mb-1">
        <span>{label}</span><span>{score.toFixed(1)}/100</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div className="bg-primary-600 h-2 rounded-full" style={{ width: `${score}%` }} />
      </div>
    </div>
  )
}