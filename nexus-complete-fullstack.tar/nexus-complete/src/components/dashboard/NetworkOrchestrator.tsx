// src/components/dashboard/NetworkOrchestrator.tsx
'use client'

import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/Card'

interface Provider {
  id: string
  name: string
  status: string
  metrics?: {
    latency: number
    signal: number
    costPerMB: number
    availability: number
  }
}

interface Session {
  id: string
  activeProvider: {
    id: string
    name: string
    metrics: any
  }
  virtualNumber: string
  uptime: number
  switchCount: number
  recentSwitches: Array<{
    from: string
    to: string
    timestamp: number
    reason: string
    scoreDelta: number
  }>
}

export default function NetworkOrchestrator() {
  const [session, setSession] = useState<Session | null>(null)
  const [providers, setProviders] = useState<Provider[]>([])
  const [loading, setLoading] = useState(true)
  const [autoSwitch, setAutoSwitch] = useState(true)

  // Load session and providers
  useEffect(() => {
    loadData()
    const interval = setInterval(loadData, 5000)
    return () => clearInterval(interval)
  }, [])

  async function loadData() {
    try {
      // Load session
      const sessionRes = await fetch('/api/orchestrator?action=session')
      if (sessionRes.ok) {
        const data = await sessionRes.json()
        setSession(data.session)
      }

      // Load providers
      const providersRes = await fetch('/api/orchestrator?action=providers')
      if (providersRes.ok) {
        const data = await providersRes.json()
        setProviders(data.providers)
      }
    } catch (error) {
      console.error('Failed to load data:', error)
    } finally {
      setLoading(false)
    }
  }

  async function triggerAutoSwitch() {
    try {
      const res = await fetch('/api/orchestrator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'auto_switch' })
      })
      
      const result = await res.json()
      
      if (result.switched) {
        alert(`Switched from ${result.from} to ${result.to}!\nReason: ${result.reason}`)
        loadData()
      } else {
        alert('Current network is already optimal')
      }
    } catch (error) {
      console.error('Auto-switch failed:', error)
    }
  }

  async function manualSwitch(providerId: string) {
    try {
      const res = await fetch('/api/orchestrator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'manual_switch',
          providerId
        })
      })
      
      const result = await res.json()
      
      if (result.success) {
        alert(`Switched to ${providerId} in ${result.switchTime}ms`)
        loadData()
      }
    } catch (error) {
      console.error('Manual switch failed:', error)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Current Session */}
      {session && (
        <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm opacity-80">Connected to</p>
                <h2 className="text-3xl font-bold">{session.activeProvider.name}</h2>
              </div>
              <div className="text-right">
                <p className="text-sm opacity-80">Your Number</p>
                <p className="text-lg font-semibold">{session.virtualNumber}</p>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 mt-6">
              <div className="bg-white/20 rounded-lg p-3">
                <p className="text-xs opacity-80">Latency</p>
                <p className="text-xl font-bold">
                  {session.activeProvider.metrics?.latency.toFixed(0)}ms
                </p>
              </div>
              <div className="bg-white/20 rounded-lg p-3">
                <p className="text-xs opacity-80">Signal</p>
                <p className="text-xl font-bold">
                  {session.activeProvider.metrics?.signal.toFixed(0)}%
                </p>
              </div>
              <div className="bg-white/20 rounded-lg p-3">
                <p className="text-xs opacity-80">Uptime</p>
                <p className="text-xl font-bold">
                  {Math.floor(session.uptime / 60000)}m
                </p>
              </div>
              <div className="bg-white/20 rounded-lg p-3">
                <p className="text-xs opacity-80">Switches</p>
                <p className="text-xl font-bold">{session.switchCount}</p>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Control Panel */}
      <Card>
        <div className="p-6">
          <h3 className="text-lg font-semibold mb-4">Control Plane</h3>
          
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="font-medium">Auto-Switch</p>
              <p className="text-sm text-gray-600">
                Automatically switch to optimal network
              </p>
            </div>
            <button
              onClick={() => setAutoSwitch(!autoSwitch)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                autoSwitch ? 'bg-blue-600' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  autoSwitch ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <button
            onClick={triggerAutoSwitch}
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
          >
            🧠 Optimize Network Now
          </button>
        </div>
      </Card>

      {/* All Networks */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Available Networks</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {providers.map(provider => (
            <Card
              key={provider.id}
              className={`cursor-pointer hover:shadow-lg transition ${
                session?.activeProvider.id === provider.id
                  ? 'ring-2 ring-blue-600'
                  : ''
              }`}
              onClick={() => manualSwitch(provider.id)}
            >
              <div className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold">{provider.name}</h4>
                  {session?.activeProvider.id === provider.id && (
                    <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded-full">
                      ACTIVE
                    </span>
                  )}
                </div>

                {provider.metrics && (
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-gray-600">Latency</p>
                      <p className="font-semibold">
                        {provider.metrics.latency.toFixed(0)}ms
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Signal</p>
                      <p className="font-semibold">
                        {provider.metrics.signal.toFixed(0)}%
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Cost</p>
                      <p className="font-semibold">
                        ${(provider.metrics.costPerMB * 1000).toFixed(2)}/GB
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Uptime</p>
                      <p className="font-semibold">
                        {provider.metrics.availability.toFixed(1)}%
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Recent Switches */}
      {session && session.recentSwitches.length > 0 && (
        <Card>
          <div className="p-6">
            <h3 className="text-lg font-semibold mb-4">Recent Switches</h3>
            <div className="space-y-3">
              {session.recentSwitches.reverse().map((sw, i) => (
                <div key={i} className="flex items-center justify-between border-b pb-3">
                  <div>
                    <p className="font-medium">
                      {sw.from} → {sw.to}
                    </p>
                    <p className="text-sm text-gray-600">{sw.reason}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-green-600 font-semibold">
                      +{sw.scoreDelta.toFixed(1)} points
                    </p>
                    <p className="text-xs text-gray-500">
                      {new Date(sw.timestamp).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}
    </div>
  )
}
