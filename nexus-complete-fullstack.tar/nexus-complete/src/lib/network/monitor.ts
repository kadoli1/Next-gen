// src/lib/network/monitor.ts
/**
 * Continuous Network Monitor
 * Runs in background to update metrics and trigger auto-switches
 * Optimized for Replit Free tier - minimal resource usage
 */

import { networkOrchestrator, type NetworkMetrics } from './orchestrator'

class NetworkMonitor {
  private intervalId: NodeJS.Timeout | null = null
  private isRunning = false
  private updateInterval = 5000 // 5 seconds - Replit-friendly

  /**
   * Simulate real-time network metrics
   * In production, this would query actual cellular APIs
   */
  private generateMetrics(providerId: string): NetworkMetrics {
    const baseMetrics = {
      'mtn_zm': { latency: 45, cost: 0.020, signal: 85, availability: 94 },
      'airtel_zm': { latency: 52, cost: 0.018, signal: 80, availability: 92 },
      'zamtel': { latency: 65, cost: 0.015, signal: 75, availability: 88 },
      'liquid_zm': { latency: 38, cost: 0.022, signal: 70, availability: 96 }
    }

    const base = baseMetrics[providerId as keyof typeof baseMetrics] || {
      latency: 50,
      cost: 0.020,
      signal: 80,
      availability: 90
    }

    // Add realistic variance
    const variance = (val: number, range: number) => 
      val + (Math.random() - 0.5) * range

    // Time-based congestion (peak hours: 12-14, 18-21)
    const hour = new Date().getHours()
    const isPeak = [12, 13, 14, 18, 19, 20, 21].includes(hour)
    const congestionFactor = isPeak ? 1.3 : 1.0

    return {
      providerId,
      timestamp: Date.now(),
      signal: Math.max(0, Math.min(100, variance(base.signal, 10))),
      latency: Math.max(10, variance(base.latency * congestionFactor, 15)),
      throughput: variance(15, 5), // Mbps
      packetLoss: variance(isPeak ? 2 : 0.5, 1),
      jitter: variance(5, 3),
      congestion: isPeak ? variance(60, 20) : variance(30, 15),
      costPerMB: base.cost,
      availability: Math.max(0, Math.min(100, variance(base.availability, 5)))
    }
  }

  /**
   * Update metrics for all providers
   */
  private updateAllMetrics() {
    const providers = networkOrchestrator.getProviders()
    
    providers.forEach(provider => {
      const metrics = this.generateMetrics(provider.id)
      networkOrchestrator.updateMetrics(provider.id, metrics)
    })
  }

  /**
   * Check all active sessions and auto-switch if needed
   */
  private async checkAutoSwitches() {
    // Get all active user sessions
    // In production, query from database
    // For now, we'll just monitor any existing sessions
    
    // This would be called for each active user
    // networkOrchestrator.monitorAndSwitch(userId)
  }

  /**
   * Start monitoring
   */
  start() {
    if (this.isRunning) {
      console.log('Monitor already running')
      return
    }

    console.log('🔄 Starting network monitor...')
    
    // Initial metrics update
    this.updateAllMetrics()
    
    // Set up interval
    this.intervalId = setInterval(() => {
      this.updateAllMetrics()
      this.checkAutoSwitches()
    }, this.updateInterval)
    
    this.isRunning = true
    console.log(`✅ Monitor running (updating every ${this.updateInterval}ms)`)
  }

  /**
   * Stop monitoring
   */
  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId)
      this.intervalId = null
      this.isRunning = false
      console.log('🛑 Monitor stopped')
    }
  }

  /**
   * Get current status
   */
  getStatus() {
    return {
      isRunning: this.isRunning,
      updateInterval: this.updateInterval,
      providers: networkOrchestrator.getProviders().map(p => ({
        id: p.id,
        name: p.name,
        metrics: networkOrchestrator.getMetrics(p.id)
      }))
    }
  }
}

// Singleton instance
export const networkMonitor = new NetworkMonitor()

// Auto-start in development
if (process.env.NODE_ENV === 'development') {
  networkMonitor.start()
}
