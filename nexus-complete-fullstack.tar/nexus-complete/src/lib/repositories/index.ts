import { getDb } from '../db'
import { NetworkMetrics } from '../scoring/engine'

export class UserRepository {
  private db = getDb()
  findByEmail(email: string) {
    return this.db.prepare('SELECT id, email, password_hash as passwordHash, full_name as fullName FROM users WHERE email = ?').get(email) as any
  }
  create(email: string, passwordHash: string, fullName: string) {
    const result = this.db.prepare('INSERT INTO users (email, password_hash, full_name) VALUES (?, ?, ?)').run(email, passwordHash, fullName)
    return this.findByEmail(email)
  }
  emailExists(email: string) {
    return (this.db.prepare('SELECT COUNT(*) as count FROM users WHERE email = ?').get(email) as any).count > 0
  }
}

export class NetworkRepository {
  private db = getDb()
  getLatestMetrics(): NetworkMetrics[] {
    return this.db.prepare(\`
      SELECT n.id as networkId, n.name as networkName, n.display_name as displayName, n.color,
             nm.latency_ms as latencyMs, nm.cost_per_mb as costPerMb,
             nm.signal_strength as signalStrength, nm.availability
      FROM networks n INNER JOIN network_metrics nm ON n.id = nm.network_id
      WHERE nm.id IN (SELECT id FROM network_metrics nm2 WHERE nm2.network_id = n.id ORDER BY nm2.recorded_at DESC LIMIT 1)
    \`).all() as NetworkMetrics[]
  }
  insertMetrics(networkId: number, latency: number, cost: number, signal: number, avail: number) {
    this.db.prepare('INSERT INTO network_metrics (network_id, latency_ms, cost_per_mb, signal_strength, availability) VALUES (?, ?, ?, ?, ?)').run(networkId, latency, cost, signal, avail)
  }
}

export class PreferenceRepository {
  private db = getDb()
  findByUserId(userId: number) {
    let pref = this.db.prepare(\`SELECT id, user_id as userId, weight_latency as weightLatency, weight_cost as weightCost,
      weight_signal as weightSignal, weight_availability as weightAvailability, auto_switch_enabled as autoSwitchEnabled
      FROM user_preferences WHERE user_id = ?\`).get(userId) as any
    if (!pref) {
      this.db.prepare('INSERT INTO user_preferences (user_id) VALUES (?)').run(userId)
      pref = this.findByUserId(userId)
    }
    return pref
  }
  update(userId: number, weights: any) {
    this.db.prepare(\`UPDATE user_preferences SET weight_latency=?, weight_cost=?, weight_signal=?, weight_availability=?,
      auto_switch_enabled=?, updated_at=CURRENT_TIMESTAMP WHERE user_id=?\`)
      .run(weights.weightLatency, weights.weightCost, weights.weightSignal, weights.weightAvailability, weights.autoSwitchEnabled ? 1 : 0, userId)
    return this.findByUserId(userId)
  }
}

export class UsageRepository {
  private db = getDb()
  getBalance(userId: number) {
    let balance = this.db.prepare('SELECT id, user_id as userId, balance_mb as balanceMb FROM user_balance WHERE user_id = ?').get(userId) as any
    if (!balance) {
      this.db.prepare('INSERT INTO user_balance (user_id) VALUES (?)').run(userId)
      balance = this.getBalance(userId)
    }
    return balance
  }
  deductBalance(userId: number, dataMb: number) {
    this.db.prepare('UPDATE user_balance SET balance_mb = balance_mb - ? WHERE user_id = ?').run(dataMb, userId)
    return this.getBalance(userId)
  }
  getHistory(userId: number, limit = 20) {
    return this.db.prepare(\`SELECT uh.*, n.display_name as networkName, n.color
      FROM usage_history uh JOIN networks n ON uh.network_id = n.id
      WHERE uh.user_id = ? ORDER BY uh.created_at DESC LIMIT ?\`).all(userId, limit)
  }
  addUsage(userId: number, networkId: number, dataMb: number, cost: number, start: string, end: string) {
    this.db.prepare('INSERT INTO usage_history (user_id, network_id, data_mb, cost, session_start, session_end) VALUES (?, ?, ?, ?, ?, ?)').run(userId, networkId, dataMb, cost, start, end)
  }
}

export class SwitchRepository {
  private db = getDb()
  recordSwitch(userId: number, fromNetworkId: number | null, toNetworkId: number, reason: string, improvement: number) {
    this.db.prepare('INSERT INTO network_switches (user_id, from_network_id, to_network_id, reason, score_improvement) VALUES (?, ?, ?, ?, ?)').run(userId, fromNetworkId, toNetworkId, reason, improvement)
  }
  getHistory(userId: number, limit = 50) {
    return this.db.prepare(\`SELECT ns.*, n.display_name as toNetworkName, n.color as toNetworkColor
      FROM network_switches ns JOIN networks n ON ns.to_network_id = n.id
      WHERE ns.user_id = ? ORDER BY ns.switched_at DESC LIMIT ?\`).all(userId, limit)
  }
}
