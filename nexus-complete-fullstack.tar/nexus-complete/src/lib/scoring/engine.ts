/**
 * Network Scoring Engine - AI CORE FOR eSIM AUTO-SWITCHING
 * Evaluates MTN, Airtel, Zamtel, and ZedMobile in real-time
 */

export interface NetworkMetrics {
  networkId: number
  networkName: string
  displayName: string
  color: string
  latencyMs: number
  costPerMb: number
  signalStrength: number
  availability: number
}

export interface UserWeights {
  weightLatency: number
  weightCost: number
  weightSignal: number
  weightAvailability: number
}

export interface NetworkScore {
  networkId: number
  networkName: string
  displayName: string
  color: string
  totalScore: number
  breakdown: {
    latencyScore: number
    costScore: number
    signalScore: number
    availabilityScore: number
  }
  metrics: NetworkMetrics
}

export interface ScoringResult {
  bestNetwork: NetworkScore
  allScores: NetworkScore[]
  timestamp: string
}

export class NetworkScoringEngine {
  private normalizeLatency(ms: number): number {
    const MIN = 20, MAX = 200
    const clamped = Math.max(MIN, Math.min(MAX, ms))
    return ((MAX - clamped) / (MAX - MIN)) * 100
  }

  private normalizeCost(cost: number): number {
    const MIN = 0.01, MAX = 0.10
    const clamped = Math.max(MIN, Math.min(MAX, cost))
    return ((MAX - clamped) / (MAX - MIN)) * 100
  }

  private normalizeSignal(signal: number): number {
    return Math.max(0, Math.min(100, signal))
  }

  private normalizeAvailability(avail: number): number {
    return Math.max(0, Math.min(1, avail)) * 100
  }

  private calculateNetworkScore(metrics: NetworkMetrics, weights: UserWeights): NetworkScore {
    const latencyScore = this.normalizeLatency(metrics.latencyMs)
    const costScore = this.normalizeCost(metrics.costPerMb)
    const signalScore = this.normalizeSignal(metrics.signalStrength)
    const availabilityScore = this.normalizeAvailability(metrics.availability)

    const totalScore =
      latencyScore * weights.weightLatency +
      costScore * weights.weightCost +
      signalScore * weights.weightSignal +
      availabilityScore * weights.weightAvailability

    return {
      networkId: metrics.networkId,
      networkName: metrics.networkName,
      displayName: metrics.displayName,
      color: metrics.color,
      totalScore: Math.round(totalScore * 100) / 100,
      breakdown: {
        latencyScore: Math.round(latencyScore * 100) / 100,
        costScore: Math.round(costScore * 100) / 100,
        signalScore: Math.round(signalScore * 100) / 100,
        availabilityScore: Math.round(availabilityScore * 100) / 100,
      },
      metrics,
    }
  }

  public evaluateNetworks(networks: NetworkMetrics[], weights: UserWeights): ScoringResult {
    const weightSum = weights.weightLatency + weights.weightCost + weights.weightSignal + weights.weightAvailability
    if (Math.abs(weightSum - 1.0) > 0.01) {
      throw new Error(`Weights must sum to 1.0, got ${weightSum}`)
    }

    const allScores = networks.map(network => this.calculateNetworkScore(network, weights))
    allScores.sort((a, b) => b.totalScore - a.totalScore)

    return {
      bestNetwork: allScores[0],
      allScores,
      timestamp: new Date().toISOString(),
    }
  }

  public simulateMetricsVariation(metrics: NetworkMetrics): NetworkMetrics {
    return {
      ...metrics,
      latencyMs: Math.round(metrics.latencyMs * (1 + (Math.random() - 0.5) * 0.2)),
      costPerMb: Math.round(metrics.costPerMb * (1 + (Math.random() - 0.5) * 0.1) * 1000) / 1000,
      signalStrength: Math.max(0, Math.min(100, metrics.signalStrength + (Math.random() - 0.5) * 10)),
      availability: Math.max(0, Math.min(1, metrics.availability + (Math.random() - 0.5) * 0.04)),
    }
  }
}
