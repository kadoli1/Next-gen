'use server'
import { getCurrentUser } from '../auth'
import { NetworkRepository, PreferenceRepository, SwitchRepository } from '../repositories'
import { NetworkScoringEngine } from '../scoring/engine'

export async function getNetworkScores() {
  const user = await getCurrentUser()
  if (!user) throw new Error('Unauthorized')
  const networkRepo = new NetworkRepository()
  const preferenceRepo = new PreferenceRepository()
  const metrics = networkRepo.getLatestMetrics()
  const prefs = preferenceRepo.findByUserId(user.userId)
  const engine = new NetworkScoringEngine()
  return engine.evaluateNetworks(metrics, {
    weightLatency: prefs.weightLatency,
    weightCost: prefs.weightCost,
    weightSignal: prefs.weightSignal,
    weightAvailability: prefs.weightAvailability,
  })
}

export async function updatePreferences(weights: any) {
  const user = await getCurrentUser()
  if (!user) throw new Error('Unauthorized')
  const preferenceRepo = new PreferenceRepository()
  const sum = weights.weightLatency + weights.weightCost + weights.weightSignal + weights.weightAvailability
  if (Math.abs(sum - 1.0) > 0.01) throw new Error('Weights must sum to 1.0')
  return { success: true, preferences: preferenceRepo.update(user.userId, weights) }
}

export async function simulateNetworkSwitch(toNetworkId: number, reason: string, improvement: number) {
  const user = await getCurrentUser()
  if (!user) throw new Error('Unauthorized')
  const switchRepo = new SwitchRepository()
  switchRepo.recordSwitch(user.userId, null, toNetworkId, reason, improvement)
  return { success: true }
}
