'use server'
import { z } from 'zod'
import { UserRepository } from '../repositories'
import { hashPassword, verifyPassword, createSession, setSessionCookie, deleteSessionCookie } from '../auth'
import { redirect } from 'next/navigation'

export async function registerAction(formData: FormData) {
  const schema = z.object({
    email: z.string().email(),
    password: z.string().min(8),
    fullName: z.string().min(2),
  })
  const validated = schema.safeParse({
    email: formData.get('email'),
    password: formData.get('password'),
    fullName: formData.get('fullName'),
  })
  if (!validated.success) return { success: false, error: validated.error.errors[0].message }
  const { email, password, fullName } = validated.data
  const userRepo = new UserRepository()
  if (userRepo.emailExists(email)) return { success: false, error: 'Email already registered' }
  const passwordHash = await hashPassword(password)
  const user = userRepo.create(email, passwordHash, fullName)
  const token = await createSession({ userId: user.id, email: user.email })
  await setSessionCookie(token)
  redirect('/dashboard')
}

export async function loginAction(formData: FormData) {
  const schema = z.object({
    email: z.string().email(),
    password: z.string().min(1),
  })
  const validated = schema.safeParse({
    email: formData.get('email'),
    password: formData.get('password'),
  })
  if (!validated.success) return { success: false, error: validated.error.errors[0].message }
  const { email, password } = validated.data
  const userRepo = new UserRepository()
  const user = userRepo.findByEmail(email)
  if (!user || !(await verifyPassword(password, user.passwordHash))) {
    return { success: false, error: 'Invalid email or password' }
  }
  const token = await createSession({ userId: user.id, email: user.email })
  await setSessionCookie(token)
  redirect('/dashboard')
}

export async function logoutAction() {
  await deleteSessionCookie()
  redirect('/login')
}
