'use server'
import { getCurrentUser } from '../auth'
import { UsageRepository } from '../repositories'

export async function getUserBalance() {
  const user = await getCurrentUser()
  if (!user) throw new Error('Unauthorized')
  return new UsageRepository().getBalance(user.userId)
}

export async function getUsageHistory() {
  const user = await getCurrentUser()
  if (!user) throw new Error('Unauthorized')
  return new UsageRepository().getHistory(user.userId)
}
