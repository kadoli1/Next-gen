import Database from 'better-sqlite3'
import path from 'path'

/**
 * Complete Database Module - Schema, Connection, Migrations
 */

let db: Database.Database | null = null

export function getDb(): Database.Database {
  if (db) return db
  const dbPath = process.env.DATABASE_PATH || path.join(process.cwd(), 'optimus.db')
  db = new Database(dbPath)
  db.pragma('journal_mode = WAL')
  db.pragma('foreign_keys = ON')
  console.log(`✅ Database connected: ${dbPath}`)
  return db
}

export function closeDb(): void {
  if (db) { db.close(); db = null }
}

// Run migrations on import
export function runMigrations() {
  const db = getDb()
  
  // Users
  db.exec(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`)

  // Networks
  db.exec(`CREATE TABLE IF NOT EXISTS networks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    color TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`)

  // Metrics
  db.exec(`CREATE TABLE IF NOT EXISTS network_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    network_id INTEGER NOT NULL,
    latency_ms INTEGER NOT NULL,
    cost_per_mb REAL NOT NULL,
    signal_strength INTEGER NOT NULL CHECK(signal_strength BETWEEN 0 AND 100),
    availability REAL NOT NULL CHECK(availability BETWEEN 0 AND 1),
    recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (network_id) REFERENCES networks(id) ON DELETE CASCADE
  )`)

  // Preferences
  db.exec(`CREATE TABLE IF NOT EXISTS user_preferences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    weight_latency REAL DEFAULT 0.25,
    weight_cost REAL DEFAULT 0.25,
    weight_signal REAL DEFAULT 0.25,
    weight_availability REAL DEFAULT 0.25,
    auto_switch_enabled BOOLEAN DEFAULT 1,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`)

  // Usage
  db.exec(`CREATE TABLE IF NOT EXISTS usage_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    network_id INTEGER NOT NULL,
    data_mb REAL NOT NULL,
    cost REAL NOT NULL,
    session_start DATETIME NOT NULL,
    session_end DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (network_id) REFERENCES networks(id) ON DELETE CASCADE
  )`)

  // Balance
  db.exec(`CREATE TABLE IF NOT EXISTS user_balance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    balance_mb REAL DEFAULT 1000.0 NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`)

  // Switches
  db.exec(`CREATE TABLE IF NOT EXISTS network_switches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    from_network_id INTEGER,
    to_network_id INTEGER NOT NULL,
    reason TEXT NOT NULL,
    score_improvement REAL,
    switched_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`)

  // Indexes
  db.exec('CREATE INDEX IF NOT EXISTS idx_network_metrics_network_id ON network_metrics(network_id)')
  db.exec('CREATE INDEX IF NOT EXISTS idx_network_metrics_recorded_at ON network_metrics(recorded_at)')
  db.exec('CREATE INDEX IF NOT EXISTS idx_usage_history_user_id ON usage_history(user_id)')
  db.exec('CREATE INDEX IF NOT EXISTS idx_network_switches_user_id ON network_switches(user_id)')

  // Seed networks
  const networkCount = db.prepare('SELECT COUNT(*) as count FROM networks').get() as { count: number }
  if (networkCount.count === 0) {
    const insert = db.prepare('INSERT INTO networks (name, display_name, color) VALUES (?, ?, ?)')
    insert.run('mtn', 'MTN Zambia', '#FFCC00')
    insert.run('airtel', 'Airtel Zambia', '#FF0000')
    insert.run('zamtel', 'Zamtel', '#009639')
    insert.run('zedmobile', 'ZedMobile', '#0066CC')
  }

  // Seed metrics
  const metricsCount = db.prepare('SELECT COUNT(*) as count FROM network_metrics').get() as { count: number }
  if (metricsCount.count === 0) {
    const insert = db.prepare('INSERT INTO network_metrics (network_id, latency_ms, cost_per_mb, signal_strength, availability) VALUES (?, ?, ?, ?, ?)')
    insert.run(1, 45, 0.05, 85, 0.98)
    insert.run(2, 35, 0.07, 90, 0.95)
    insert.run(3, 65, 0.03, 75, 0.92)
    insert.run(4, 50, 0.04, 80, 0.94)
  }
}

if (process.env.NODE_ENV === 'development') {
  runMigrations()
}

process.on('exit', closeDb)
