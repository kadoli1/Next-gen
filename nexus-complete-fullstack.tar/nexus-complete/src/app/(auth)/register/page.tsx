'use client'
import { useState } from 'react'
import Link from 'next/link'
import { registerAction } from '@/lib/actions/auth'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Card, CardHeader, CardBody } from '@/components/ui/Card'
export default function RegisterPage() {
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  async function handleSubmit(formData: FormData) {
    setLoading(true)
    setError('')
    const result = await registerAction(formData)
    if (result && !result.success) {
      setError(result.error)
      setLoading(false)
    }
  }
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-primary-100 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary-600 rounded-xl flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-3xl">O</span>
          </div>
          <h1 className="text-3xl font-bold">Get started</h1>
        </div>
        <Card>
          <CardHeader><h2 className="text-xl font-semibold">Sign up</h2></CardHeader>
          <CardBody>
            <form action={handleSubmit} className="space-y-4">
              {error && <div className="p-3 bg-red-50 border border-red-200 rounded-lg"><p className="text-sm text-red-600">{error}</p></div>}
              <Input type="text" name="fullName" label="Full Name" placeholder="John Doe" required />
              <Input type="email" name="email" label="Email" placeholder="you@example.com" required />
              <Input type="password" name="password" label="Password" placeholder="••••••••" required />
              <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Creating account...' : 'Create account'}</Button>
            </form>
            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">Already have an account? <Link href="/login" className="text-primary-600 font-medium">Sign in</Link></p>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  )
}