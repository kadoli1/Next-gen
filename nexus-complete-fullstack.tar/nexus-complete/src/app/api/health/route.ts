import { NextResponse } from 'next/server'
import { getDb } from '@/lib/db'
export async function GET() {
  try {
    getDb().prepare('SELECT 1').get()
    return NextResponse.json({ status: 'ok', timestamp: new Date().toISOString() })
  } catch (error) {
    return NextResponse.json({ status: 'error', message: error instanceof Error ? error.message : 'Unknown' }, { status: 500 })
  }
}