// src/app/api/orchestrator/route.ts
/**
 * Network Orchestration API
 * RESTful endpoints for carrier-agnostic control
 */

import { NextRequest, NextResponse } from 'next/server'
import { networkOrchestrator } from '@/lib/network/orchestrator'
import { getServerSession } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const session = await getServerSession(req)
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const action = searchParams.get('action')

  switch (action) {
    case 'session':
      return getSessionStatus(session.userId)
    
    case 'providers':
      return getAvailableProviders()
    
    case 'metrics':
      return getProviderMetrics(searchParams.get('providerId'))
    
    default:
      return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(req)
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await req.json()
  const { action } = body

  switch (action) {
    case 'create_session':
      return createUserSession(session.userId, body)
    
    case 'update_policy':
      return updateUserPolicy(session.userId, body)
    
    case 'manual_switch':
      return manualSwitch(session.userId, body.providerId)
    
    case 'auto_switch':
      return autoSwitch(session.userId)
    
    default:
      return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  }
}

// Helper functions
async function getSessionStatus(userId: string) {
  const session = networkOrchestrator.getSession(userId)
  
  if (!session) {
    return NextResponse.json({ error: 'No active session' }, { status: 404 })
  }

  const currentProvider = networkOrchestrator.getProviders()
    .find(p => p.id === session.activeProviderId)
  
  const currentMetrics = networkOrchestrator.getMetrics(session.activeProviderId)

  return NextResponse.json({
    session: {
      id: session.sessionId,
      activeProvider: {
        id: session.activeProviderId,
        name: currentProvider?.name,
        metrics: currentMetrics
      },
      virtualNumber: session.virtualNumber,
      uptime: Date.now() - session.startTime,
      switchCount: session.switchCount,
      dataUsed: session.dataUsed,
      recentSwitches: session.switchHistory.slice(-5)
    }
  })
}

async function getAvailableProviders() {
  const providers = networkOrchestrator.getProviders()
  
  const providersWithMetrics = providers.map(provider => ({
    ...provider,
    metrics: networkOrchestrator.getMetrics(provider.id)
  }))

  return NextResponse.json({ providers: providersWithMetrics })
}

async function getProviderMetrics(providerId: string | null) {
  if (!providerId) {
    return NextResponse.json({ error: 'Provider ID required' }, { status: 400 })
  }

  const metrics = networkOrchestrator.getMetrics(providerId)
  
  if (!metrics) {
    return NextResponse.json({ error: 'Metrics not found' }, { status: 404 })
  }

  return NextResponse.json({ metrics })
}

async function createUserSession(userId: string, body: any) {
  const { virtualNumber, policy } = body

  if (!virtualNumber) {
    return NextResponse.json(
      { error: 'Virtual number required' },
      { status: 400 }
    )
  }

  // Set policy if provided
  if (policy) {
    networkOrchestrator.setPolicy(userId, policy)
  } else {
    // Default balanced policy
    networkOrchestrator.setPolicy(userId, {
      userId,
      priority: 'balanced',
      weights: {
        latency: 0.3,
        cost: 0.25,
        signal: 0.25,
        reliability: 0.2
      },
      constraints: {},
      autoSwitch: true,
      switchThreshold: 10
    })
  }

  const session = networkOrchestrator.createSession(userId, virtualNumber)

  return NextResponse.json({
    success: true,
    session: {
      id: session.sessionId,
      activeProvider: session.activeProviderId,
      virtualNumber: session.virtualNumber
    }
  })
}

async function updateUserPolicy(userId: string, body: any) {
  const { policy } = body

  if (!policy) {
    return NextResponse.json({ error: 'Policy required' }, { status: 400 })
  }

  networkOrchestrator.setPolicy(userId, {
    ...policy,
    userId
  })

  return NextResponse.json({ success: true })
}

async function manualSwitch(userId: string, targetProviderId: string) {
  if (!targetProviderId) {
    return NextResponse.json(
      { error: 'Target provider required' },
      { status: 400 }
    )
  }

  const result = await networkOrchestrator.switchNetwork(
    userId,
    targetProviderId,
    'manual_user_switch'
  )

  return NextResponse.json(result)
}

async function autoSwitch(userId: string) {
  const result = await networkOrchestrator.monitorAndSwitch(userId)
  return NextResponse.json(result)
}
