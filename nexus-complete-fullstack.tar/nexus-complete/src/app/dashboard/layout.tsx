import { Header } from '@/components/layout/Header'
import Link from 'next/link'
export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-6">
        <nav className="flex gap-4 mb-6">
          <Link href="/dashboard" className="px-4 py-2 rounded-lg bg-white hover:bg-gray-100">Dashboard</Link>
          <Link href="/dashboard/analytics" className="px-4 py-2 rounded-lg bg-white hover:bg-gray-100">Analytics</Link>
          <Link href="/dashboard/history" className="px-4 py-2 rounded-lg bg-white hover:bg-gray-100">History</Link>
        </nav>
        {children}
      </div>
    </div>
  )
}