import { getUsageHistory } from '@/lib/actions/usage'
import { Card, CardBody } from '@/components/ui/Card'
export const dynamic = 'force-dynamic'
export default async function HistoryPage() {
  const history = await getUsageHistory()
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Usage History</h1>
      <div className="space-y-3">
        {history.length === 0 ? (
          <Card><CardBody><p className="text-gray-600 text-center">No usage history yet</p></CardBody></Card>
        ) : (
          history.map((item: any) => (
            <Card key={item.id}>
              <CardBody>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <div>
                      <p className="font-medium">{item.networkName}</p>
                      <p className="text-sm text-gray-600">{new Date(item.created_at).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{item.data_mb.toFixed(2)} MB</p>
                    <p className="text-sm text-gray-600">${item.cost.toFixed(2)}</p>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}