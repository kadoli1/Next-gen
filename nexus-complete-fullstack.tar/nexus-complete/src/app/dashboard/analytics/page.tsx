export default function AnalyticsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Analytics</h1>
      <div className="bg-white rounded-lg p-8 text-center">
        <p className="text-gray-600">Analytics charts coming soon!</p>
        <p className="text-sm text-gray-500 mt-2">Network performance trends, cost analysis, and more</p>
      </div>
    </div>
  )
}