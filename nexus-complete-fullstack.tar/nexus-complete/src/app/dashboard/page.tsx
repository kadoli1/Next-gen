import { getNetworkScores } from '@/lib/actions/network'
import { getUserBalance } from '@/lib/actions/usage'
import { NetworkCard } from '@/components/dashboard/NetworkCard'
import { Card, CardBody } from '@/components/ui/Card'
export const dynamic = 'force-dynamic'
export default async function DashboardPage() {
  const scores = await getNetworkScores()
  const balance = await getUserBalance()
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      <Card className="mb-8">
        <CardBody>
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-600">Data Balance</p>
              <p className="text-3xl font-bold">{balance.balanceMb.toFixed(2)} MB</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Active Network</p>
              <p className="text-xl font-semibold text-primary-600">{scores.bestNetwork.displayName}</p>
            </div>
          </div>
        </CardBody>
      </Card>
      <h2 className="text-xl font-semibold mb-4">Network Rankings</h2>
      <div className="space-y-4">
        {scores.allScores.map((network, i) => (
          <NetworkCard key={network.networkId} network={network} isBest={i === 0} />
        ))}
      </div>
    </div>
  )
}